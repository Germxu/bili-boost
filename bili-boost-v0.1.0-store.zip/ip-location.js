"use strict";
/**
 * Bili Boost - 评论区 IP 属地注入（MAIN world）
 *
 * B站视频评论区使用 Lit Web Component。评论数据挂在组件实例的 data 属性上，
 * 而内容脚本运行在 isolated world，拿不到页面脚本设置的 expando 属性，
 * 所以必须在 MAIN world 中 patch 组件。
 *
 * 此文件是源代码，编译后输出到 public/ip-location.js，再由 Vite 复制到 dist/。
 */
;
(function () {
    'use strict';
    const TAG = '[BiliBoost][main]';
    const FLAG_KEY = 'biliBoost_ipEnabled';
    const CE_NAME = 'bili-comment-action-buttons-renderer';
    const BADGE_ID = 'bili-boost-ip';
    let debugCount = 0;
    function isEnabled() {
        return localStorage.getItem(FLAG_KEY) !== '0';
    }
    function readLocation(data) {
        const raw = data?.reply_control?.location;
        if (!raw)
            return null;
        return String(raw).replace(/^IP属地[:：]?/, '').trim() || null;
    }
    function updateElement(el) {
        const root = el.shadowRoot;
        if (!root)
            return;
        const pubdate = root.querySelector('#pubdate');
        if (!pubdate)
            return;
        let badge = root.querySelector(`#${BADGE_ID}`);
        const location = isEnabled() ? readLocation(el.data) : null;
        if (debugCount < 4) {
            debugCount += 1;
            console.info(TAG, 'component seen, data =', el.data ? Object.keys(el.data).slice(0, 12) : 'undefined', 'location =', location);
        }
        if (!location) {
            badge?.remove();
            return;
        }
        const text = `IP：${location}`;
        if (badge) {
            if (badge.textContent !== text)
                badge.textContent = text;
            return;
        }
        badge = document.createElement('div');
        badge.id = BADGE_ID;
        badge.textContent = text;
        badge.style.cssText = 'margin-top:2px;color:#9499a0;font-size:12px;line-height:1.4;';
        pubdate.insertAdjacentElement('afterend', badge);
    }
    function patchConstructor(ctor) {
        if (!ctor?.prototype || typeof ctor.prototype.update !== 'function')
            return;
        if (ctor.prototype.__biliBoostPatched)
            return;
        const original = ctor.prototype.update;
        ctor.prototype.update = function (...args) {
            const result = original.apply(this, args);
            try {
                updateElement(this);
            }
            catch (error) {
                console.warn(TAG, 'update failed', error);
            }
            return result;
        };
        ctor.prototype.__biliBoostPatched = true;
        console.info(TAG, 'patched update() of', CE_NAME);
    }
    function scan(root, depth) {
        if (depth > 6)
            return;
        root.querySelectorAll(CE_NAME).forEach(updateElement);
        root.querySelectorAll('*').forEach((el) => {
            if (el.shadowRoot)
                scan(el.shadowRoot, depth + 1);
        });
    }
    function removeAllBadges() {
        document.querySelectorAll(`#${BADGE_ID}`).forEach((el) => el.remove());
        document.querySelectorAll('*').forEach((el) => {
            el.shadowRoot?.querySelectorAll(`#${BADGE_ID}`).forEach((badge) => badge.remove());
        });
    }
    const registry = window.customElements;
    if (registry) {
        const existing = registry.get(CE_NAME);
        if (existing)
            patchConstructor(existing);
        const originalDefine = registry.define.bind(registry);
        registry.define = function (name, ctor, options) {
            if (name === CE_NAME)
                patchConstructor(ctor);
            originalDefine(name, ctor, options);
        };
    }
    // 兜底扫描：覆盖 data 晚于首次 update 赋值、以及切换评论列表的情况。
    const timer = window.setInterval(() => {
        if (!isEnabled()) {
            removeAllBadges();
            return;
        }
        scan(document, 0);
    }, 1200);
    window.addEventListener('pagehide', () => window.clearInterval(timer), { once: true });
    window.addEventListener('storage', (event) => {
        if (event.key === FLAG_KEY && event.newValue === '0')
            removeAllBadges();
    });
    console.info(TAG, 'loaded');
})();
